<?php
session_start();
require "bdd.php";

if(isset($_POST["connection"])){
    var_dump($_POST["password"]);
    
       
        $username = htmlspecialchars($_POST["username"]);
        $password = htmlspecialchars($_POST["password"]);
        $get_user = $bdd->prepare('SELECT * FROM users WHERE username = ? and passw = ?');
        $get_user->execute(array($username,$password));
        
        if($get_user->rowCount() > 0 ){
            
            $_SESSION["username"] = $get_user->fetch();
            header("location:products.php");
        }else{

        }
    
  
}else{

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de connexion</title>
</head>
<body>
    <form action="" method="POST">
        <label for="username">Username :</label>
        <input type="text" name="username">

        <label for="password">Password :</label>
        <input type="password" name="password">

        <input type="submit" name="connection">
        
    </form>
    
</body>
</html>