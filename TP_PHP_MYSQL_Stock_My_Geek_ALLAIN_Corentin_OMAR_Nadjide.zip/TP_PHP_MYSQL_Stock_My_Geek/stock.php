<?php
echo "Stock disponible : ";
$bdd->exec('UPDATE products SET quantity WHERE produtcname = TASSE');

echo $_SESSION["productname"];
?>