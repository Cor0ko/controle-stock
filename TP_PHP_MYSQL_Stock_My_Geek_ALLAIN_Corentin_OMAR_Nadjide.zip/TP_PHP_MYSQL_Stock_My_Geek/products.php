<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" />
    <title>Products</title>
</head>
<body>
    <h1>Bienvenue sur Syock My Geek !</h1>
         <div id="Mug">
             <img alt="muggeek" height="300px" src="./asset/10875641-mug-blanc-un-geek-ne-meurt-pas-by-tunetoo.webp">
             <h3><U><a href="Mug.html">Mug Geek</a></U></h3>
         </div>

         <div id="Manette">
             <img alt="manetteLED" height="300px" src="./asset/1635473422a4b5b327f95f9739d8b66efd078d3dd7_thumbnail_405x552.jpg">
             <h3><U><a href="ManetteLED.html">Mannette LED</a></U></h3>
         </div>

    </body>
</html>
</body>
</html>